package game;

import java.util.*;

public class TicTacToeProgram {

	TicTacToe tictactoe;

	public void init() {
		tictactoe = new TicTacToe();
	}

	public void run() {
		Scanner scanner = new Scanner(System.in);
		while (!tictactoe.hasWon()) {
			System.out.println(tictactoe);
			System.out.println("Player " + tictactoe.getPlayer()
					+ " enter column and rad:");
			int r = scanner.nextInt();
			int c = scanner.nextInt();
			if (tictactoe.placePiece(r, c)) {
				tictactoe.changePlayer();
			}
			if (tictactoe.hasWon()) {
				System.out.println(tictactoe);
				tictactoe.changePlayer();
				System.out.println("Player " + tictactoe.getPlayer()
						+ " has won");
			}
			if(tictactoe.noWinner()){
				System.out.println(tictactoe);
				System.out.println("The game ended in a draw!");
				break;
			}

		}
	}

	public static void main(String[] args) {
		TicTacToeProgram tttp = new TicTacToeProgram();
		tttp.init();
		tttp.run();
	}

}
