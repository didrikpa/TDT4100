package stateandbehaviour;

public class StackProgram {

}
