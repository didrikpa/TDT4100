package stateandbehaviour;

public class LocationProgram {
	public static void main(String[] args){
		Location sted = new Location();
		sted.down();
		
		System.out.print(sted.x);
		System.out.print(", ");
		System.out.print(sted.y);
		
		
		
	}

}
