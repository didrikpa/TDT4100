package stateandbehaviour;

public class LineEditorProgram {
	public static void main(String[] args)
	{
		LineEditor nyStreng = new LineEditor("This is SPARTA", 9);
		nyStreng.deleteLeft();
		System.out.println(nyStreng.text);
	}
	
}
