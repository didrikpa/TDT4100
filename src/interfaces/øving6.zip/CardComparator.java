package interfaces;

public class CardComparator {

}
