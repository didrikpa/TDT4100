package encapsulation;

public class PersonProgram {
	
	public static void main(String[] args){
		private String name;
		private String email;
		
		Person person = new Person();
		person.setName(name);
		person.setEmail(email);
	}
	
	
}